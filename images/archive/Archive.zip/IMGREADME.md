## YAY IMAGES TO EDIT

so I have a bunch of images i need to edit:

- blue.jpg
- red.jpg
Make transparent background, adjust size of red.jpg image and same proportions as blue.jpg

- faery1.jpg
- ...
- faery1.jpg
Make transparent background, and same proportions as blue.jpg (within reason)

- dragon1.png
- ...
- dragon17.png
Already transparent background I think, just same same proportions as blue.jpg (within reason)

- blueattack.gif
- redattack.gif
Make transparent background, and make still image version, so I can go from still->animation->still

- hero1.jpg
- hero2.jpg
Make transparent background

- boss1.jpg
- boss2.jpg
Remove that sneaky bottom line there

- castle.png
I want a zoom transition thingo into the center/towards the gate (like going in). Dunno if there is some photoshop/css/magic way to do that


